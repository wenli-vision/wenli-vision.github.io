function pair_all_all = rand_pair_gen_norep(train_num_all,dpair_num)


pair_num = 10*dpair_num;

xindx = floor((train_num_all+1)*rand(pair_num,1));
yindx = floor((train_num_all+1)*rand(pair_num,1));

ind_lb = xindx<1;xindx(ind_lb) = 1;
ind_lb = yindx<1;yindx(ind_lb) = 1;

ind_same = (xindx==yindx);
xindx(ind_same) = [];yindx(ind_same) = [];

pair_all_all = [xindx,yindx];
pair_all_all = unique(pair_all_all,'rows');

rindx = find(pair_all_all(:,1) <= pair_all_all(:,2));
pair_all_all(rindx,:) = [];

end