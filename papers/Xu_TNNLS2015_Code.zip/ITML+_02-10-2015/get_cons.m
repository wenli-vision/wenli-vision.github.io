function C = get_cons(pos_pair_all,neg_pair_all,u,l)

pos_num = size(pos_pair_all,1);
neg_num = size(neg_pair_all,1);
tr_num = pos_num + neg_num;
C = zeros(tr_num, 4);

for cth = 1:pos_num % similiar pairs;
    C(cth,1) = pos_pair_all(cth,1);
    C(cth,2) = pos_pair_all(cth,2);
    C(cth,3) = 1;
    C(cth,4) = l;
end

for cth = 1+pos_num:tr_num % dissimiliar pairs;
    C(cth,1) = neg_pair_all(cth-pos_num,1);
    C(cth,2) = neg_pair_all(cth-pos_num,2);
    C(cth,3) = -1;
    C(cth,4) = u;
end

end
