function decs_test = cal_dist_maha(A,Xte,test_pair)

te_num = size(test_pair,1);
decs_test = zeros(te_num,1);
for tth = 1:te_num
    avec = Xte(test_pair(tth,1),:);
    bvec = Xte(test_pair(tth,2),:);
    decs_test(tth,1) = (avec-bvec)*A*(avec-bvec)';
end

%decs_test = -decs_test;

end




