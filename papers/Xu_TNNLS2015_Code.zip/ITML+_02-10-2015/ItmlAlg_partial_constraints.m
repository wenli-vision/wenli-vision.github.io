function [A, history] = ItmlAlg_partial_constraints(C, Xin, params)

%% The information-theoretic metric learning with privileged information (ITML+) algorithm
% 
% Xinxing Xu, Wen Li, Dong Xu,
% Distance Metric Learning Using Privileged Information for Face Verification and Person Re-Identification
% Neural Networks and Learning Systems, IEEE Transactions on  (Volume:PP ,
% Issue: 99 ), 2015;
%% Input:
% C: 5 column matrix
%      column 1, 2: index of constrained points.  Indexes between 1 and n
%      column 3: 1 if points are similar, -1 if dissimilar
%      column 4: right-hand side (lower or upper bound, depending on 
%                   whether points are similar or dissimilar)
%      column 5: 1 if the pair has a privileged constraint; 

% X: (n x m) data matrix - each row corresponds to a single instance
%
% params: algorithm parameters - see see SetDefaultParams for defaults
%           params.thresh: algorithm convergence threshold
%           params.gamma: gamma value for slack variables
%           params.max_iters: maximum number of iterations
%
% returns A: learned Mahalanobis matrix
% Code from Xinxing Xu, Contact: xxxing1987@gmail.com


X = Xin{1};
Xp = Xin{2};

x_dim = size(X,2);
xp_dim = size(Xp,2);

A_0 = diag(ones(x_dim,1));
P_0 = diag(ones(xp_dim,1));

% Core ITML+ learning algorithm
% 

tol = params.thresh;
gamma = params.gamma;
lambda = params.lambda; 
max_iters = params.max_iters;


% check to make sure that no 2 constrained vectors are identical
valid = ones(size(C,1),1);
for (i=1:size(C,1)),
   i1 = C(i,1);
   i2 = C(i,2);
   v = X(i1,:)' - X(i2,:)'; 
   vp = Xp(i1,:)'-Xp(i2,:)';
   if (norm(v) < 10e-10)||(norm(vp) <1e-10),
      valid(i) = 0;
   end
end
C = C(valid>0,:);

i = 1;
iter = 0;
c = size(C, 1);
bhat = C(:,4); 
ys = C(:,3);
taus = bhat; 

xis = taus;xis_inv = 1./xis;
alphaold = zeros(c,1);alpha = alphaold;
alphac = zeros(c,1);
betaold = zeros(c,1);beta = betaold;
alphac_old = alphac;

conv = Inf;
A = A_0;
P = P_0;

while (true),
    i1 = C(i,1);
    i2 = C(i,2);
    v = X(i1,:)' - X(i2,:)';
    wtw = v'*A*v; r = wtw;
    u = Xp(i1,:)' - Xp(i2,:)';
    utu = u'*P*u; s = utu;
    
    if utu<1e-10 || r<1e-10
       u = u; 
    end
    
    if (abs(bhat(i)) < 10e-10),
        error('bhat should never be 0!');
    end
    
    yd_cur = C(i,5);
    UPDATE_TYPE = 3;
    if yd_cur == 1 % for the pairs with the privileged constraint;
            y_cur = ys(i);
            xi_cur_old = xis(i);
            alpha_temp = max(0, 1/((lambda+gamma+1)*y_cur)*(gamma./xi_cur_old + lambda./s - (lambda + gamma)./r));
            alphac(i) = 0;
            
            beta_cur = lambda/(lambda+gamma)*(gamma./s - gamma./xi_cur_old + y_cur*alpha_temp);
            xi_cur = lambda*s/(lambda - s*beta_cur);
            
            xis(i) = xi_cur;
            xi_cur_inv = 1./xi_cur;        
    elseif yd_cur == 0 % for the pairs without the privileged constraint;
        y_cur = ys(i);
        xi_cur_old = xis(i);
        alpha_temp = max(alphac(i), gamma/((gamma+1)*y_cur)*(1./xi_cur_old - 1./r));
        alphac(i) = alphac(i) - alpha_temp;
        xi_cur = inv(1./xi_cur_old - alpha_temp*y_cur./gamma);
        beta_cur = 0;
        xis(i) = xi_cur;
        xi_cur_inv = 1./xi_cur;
    end
    
    %%
    xis_inv(i) = xi_cur_inv;% update 1/xi;
    alpha(i,1) = alpha_temp;% update alpha;
    beta(i,1) = beta_cur;% update beta;
    a_temp = -y_cur*alpha_temp/(1 + y_cur*alpha_temp*r);%modified on 12-6;
    p_temp = -beta_cur/(lambda - beta_cur*s);%modified on 12-6;

    A = A + a_temp*A*v*(v')*A;% update M;
    P = P - p_temp*P*u*(u')*P;% update P;

    if i == 158
       i = i; 
    end
    
   
    
    if i == c
        xvs = [alpha;beta];
        xvs_old = [alphaold;betaold];
        if UPDATE_TYPE==2
            normsum = norm(alphac) + norm(alphac_old);
        elseif UPDATE_TYPE==3||UPDATE_TYPE==0
            normsum = norm(alpha) + norm(alphaold);
        end
        if (normsum == 0)
            break;
        else
            if UPDATE_TYPE==2
                conv = norm(alphac_old - alphac,1)/normsum;
            elseif UPDATE_TYPE==3||UPDATE_TYPE==2
                conv = norm(alphaold - alpha,1)/normsum;
            end

            if (conv < tol || iter > max_iters),
                break;
            end
        end
        alphaold = alpha;
        betaold = beta;
        alphac_old = alphac;
    end
    i = mod(i,c) + 1;

    iter = iter + 1;
    if (mod(iter, 5000) == 0),       
       disp(sprintf('itml+ iter: %d, conv = %f', iter, conv));
    end
end

history.P = P;
history.A = A;
history.xi = xis;
history.alpha = alpha;
history.beta = beta;
history.dist_main = cal_dist_maha(A,X,C(:,1:2));
history.dist_p = cal_dist_maha(P,Xp,C(:,1:2));
history.taus = taus;

disp(sprintf('itml+ converged to tol: %f, iter: %d', conv, iter));



