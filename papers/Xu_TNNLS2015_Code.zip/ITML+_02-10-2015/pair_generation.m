function [pos_pair_all,neg_pair_all] = pair_generation(y,spair_num)

y_train = y;
rng;
num_class_tr = length(unique(y_train));
train_num_all = length(y_train);

spair_num = spair_num;
dpair_num = spair_num*num_class_tr;

num_per_class = 20;
spair_num_all = num_per_class*(num_per_class-1)/2;
pair_all = [];
for ith = 1:num_per_class
    for jth = 1:ith-1
        pair_cur = [ith,jth];
        pair_all = [pair_all;pair_cur];
    end
end

yname = unique(y_train);
pos_pair_all = [];
pair_pos_all_all = [];
cth_num = zeros(num_class_tr,1);
for cth = 1:num_class_tr
    cname_cur = yname(cth);
    cth_num_cur = sum(y_train == cname_cur);cth_num(cth,1) = cth_num_cur;

    pair_pos_rd = pair_all;
    sindx_perm = randperm(size(pair_pos_rd,1));
    pair_pos_cur = pair_pos_rd(sindx_perm(1:spair_num),:);
    pair_pos_cth = pair_pos_cur + sum(cth_num(1:cth-1,1));
    pos_pair_all = [pos_pair_all;pair_pos_cth];

    pair_pos_all_all = [pair_pos_all_all;pair_all + sum(cth_num(1:cth-1,1))];
end
spair_all_all = pair_pos_all_all;
pair_all_all = rand_pair_gen_norep(train_num_all,dpair_num);

dis_pair_all = setdiff(pair_all_all,spair_all_all,'rows');
dis_pair_num = size(dis_pair_all,1);
rand_indt = randperm(dis_pair_num);
rand_indx_d = rand_indt(1:dpair_num);
neg_pair_all = dis_pair_all(rand_indx_d,:);
end


