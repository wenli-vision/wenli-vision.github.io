function toy_ITML_plus()

%% Sample code for using ITML+
% 
% Xinxing Xu, Wen Li, Dong Xu,
% Distance Metric Learning Using Privileged Information for Face Verification and Person Re-Identification
% Neural Networks and Learning Systems, IEEE Transactions on  (Volume:PP ,
% Issue: 99 ), 2015;
% Code from  Xinxing Xu, Contact: xxxing1987@gmail.com

%% prepare the training data;
Xin{1} = randn(1000,150);% main feature;
Xin{2} = randn(1000,100);% privileged feature;
for yth = 1:50
    y(1+(yth-1)*20:yth*20,1) = yth;
end
spair_num = 19*20/2;
[tpos_pair_all,tneg_pair_all] = pair_generation(y,spair_num);
%% set the parameters;
M0 = eye(size(Xin{1},2));
[l,u] = ComputeDistanceExtremes_L2_1K(Xin{1}, 5, 95, M0);
C = get_cons(tpos_pair_all,tneg_pair_all,u,l);
params = SetDefaultParams([]);
opt.dy = 1;

dy = [ones(size(tpos_pair_all,1),1);ones(size(tneg_pair_all,1),1)];
opt.dy_preset = dy;

if opt.dy == 0 % reduces to ITML;
    dy = [ones(size(tpos_pair_all,1),1);ones(size(tneg_pair_all,1),1)];
elseif opt.dy == 1 % ITML+;
    dy = [zeros(size(tpos_pair_all,1),1);ones(size(tneg_pair_all,1),1)];
elseif opt.dy == 2 % partial ITML+; 1 in dy means using the pri
    dy = opt.dy_preset;
end
C = [C,dy];
%% train the distance metric A;
[A, history] = ItmlAlg_partial_constraints(C, Xin, params);

end