function [] = show_param(param)
%% parameters
disp(' ');
disp('************************ show paramters **************************');

%domain generalization/adaptation
if isfield(param, 'dam_flag')
    switch param.dam_flag
        case 0
            disp('dg: no target data');
        case 1
            disp('da: unsuprevised');
        otherwise
            disp('warning: dam_flag: unknown');
    end
end

disp(' ');
disp('*** LRE_SVMs param: ');
if isfield(param, 'svm_C')
    disp(['C: ' num2str(param.svm_C)]);
end
if isfield(param, 'exemplar_weight')
    disp(['Weight: ' num2str(param.exemplar_weight)]);
end
if isfield(param, 'lambda1')
    disp(['Lambda_1: ' num2str(param.lambda1)]);
end
if isfield(param, 'lambda2')
    disp(['Lambda_2: ' num2str(param.lambda2)]);
end
if isfield(param, 'prdct_top_num')
    disp(['top_exemplar_num: ' num2str(param.prdct_top_num)]);
end

disp(' ');
disp('*** DAM param: ');
if isfield(param, 'mmd_sig')
    disp(['mmd kernel sigma: ' num2str(param.mmd_sig)]);
end
if isfield(param, 'dam_sig')
    disp(['dam kernel sigma: ' num2str(param.dam_sig)]);
end
if isfield(param, 'dam_g1')
    disp(['dam C: ' num2str(param.dam_g1)]);
end
if isfield(param, 'dam_g2')
    disp(['dam lambda: ' num2str(param.dam_g2)]);
end
if isfield(param, 'dam_eps')
    disp(['dam eps: ' num2str(param.dam_eps)]);
end

disp(' ');
disp('*** Optimization param:');
if isfield(param, 'max_ite')
    disp(['Max Ite: ' num2str(param.max_ite)]);
end
if isfield(param, 'max_inner_ite')
    disp(['Max Inner Ite: ' num2str(param.max_inner_ite)]);
end
if isfield(param, 'min_f_thred')
    disp(['Min f: ' num2str(param.min_f_thred)]);
end
if isfield(param, 'min_obj_val')
    disp(['Min obj: ' num2str(param.min_obj_val)]);
end
if isfield(param, 'dam_min_stop')
    disp(['DAM Min : ' num2str(param.dam_min_stop)]);
end

disp('******************************************************************');
disp(' ');
end