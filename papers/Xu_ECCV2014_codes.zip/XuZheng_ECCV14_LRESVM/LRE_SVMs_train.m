function model = LRE_SVMs_train(data, param)

train_ftr = data.ftr;
train_lbl = data.lbl;
[trn_smpl_num, ftr_dim] = size(train_ftr);
cate_num = max(train_lbl);

weights = zeros(size(train_ftr));
bias = zeros(trn_smpl_num, 1);
for cate_i = 1:cate_num
    disp(['LRE_SVMs training... : category : ' num2str(cate_i)]);
    cate_idx = (train_lbl == cate_i);
    tmp_trn_lbl = 2 * cate_idx - 1;
    
    param.cate_i = cate_i;
    param.cate_j = 0;
    tmp_file = binary_model_path(param);
    switch param.save_model_flag
        case 2
            if exist(tmp_file, 'file')
                load(tmp_file, 'tmp_model');
                disp(['load model from: ' tmp_file]);
            else
                disp('no model: creating...');
                tmp_model = LRE_SVMs_binary_train(train_ftr, tmp_trn_lbl, param);
                save(tmp_file, 'tmp_model');
                disp(['save model to: ' tmp_file]);
            end
        case 1
            tmp_model = LRE_SVMs_binary_train(train_ftr, tmp_trn_lbl, param);
            save(tmp_file, 'tmp_model');
            disp(['save model to: ' tmp_file]);
        case 0
            tmp_model = LRE_SVMs_binary_train(train_ftr, tmp_trn_lbl, param);
        otherwise
            disp(['unknown save_model_flag: ' num2str(param.save_model_flag)]);
    end
    
    weights(cate_idx, :) = tmp_model.weights;
    bias(cate_idx) = tmp_model.bias;
end
model.esvm.esvm_weights = weights;
model.esvm.esvm_bias = bias;
model.esvm.train_lbl = train_lbl;
model.cate_num = cate_num;
model.trn_smpl_num = trn_smpl_num;
model.dam_flag = param.dam_flag;
model.prdct_top_num = param.prdct_top_num;

model.dam_C = param.dam_g1;
model.dam_lambda = param.dam_g2;
model.dam_eps = param.dam_eps;
end


function  file = binary_model_path(param)
file = [
    param.model_path...   %path
    'C' num2str(param.svm_C) ... %svm C
    'W' num2str(param.exemplar_weight) ... %exemplar weight
    'L' num2str(param.lambda1) '-' num2str(param.lambda2) ...%lambda
    'c' num2str(param.cate_i) '-' num2str(param.cate_j) ...%category
    '.model.mat'...
    ];
end
