MATLAB Code for 

************************************************************

Exploiting Low-Rank Structure from Latent Domains
In ECCV 2014

Contact: Zheng Xu (xuzhustc@gmail.com)

*************************************************************

v1, Sep, 2014


Run demo.m
Have fun!

The code may need hours, please be patient. Thanks!



Bundled Code
The code is tested under MATLAB R2013b, Windows 7. The code is self-contained. We use codes downloaded from 
http://www.cs.ubc.ca/~schmidtm/Software/minFunc.html
http://www.csie.ntu.edu.tw/~cjlin/libsvm/
http://www.mathworks.com/matlabcentral/fileexchange/23576-min-max-selection
We thank their generous sharing. Please check those sites for that part of the code. 


Feature and Data
The DeCAF features (https://github.com/UCB-ICSI-Vision-Group/decaf-release/), which are output of fully connected layer of deep convolutional neural networks, are extracted for Office_Caltech dataset(http://www-scf.usc.edu/~boqinggo/domainadaptation.html)
Please also refer to
http://vc.sce.ntu.edu.sg/transfer_learning_domain_adaptation/domain_adaptation_home.html


Parameter Tuning
The code is slightly changed after the paper is published. If you have questions about reproducing results in the paper, please kindly contact the authors. We suggest first try tuning parameters C, lambda1, lambda2 for domain generalization.


This is the work I have done at NTU, Singapore. Thanks a lot for the efforts of my coauthors, Wen Li, Li Niu and Dong Xu. Please cite our paper if you would like to use the code:

Exploiting Low-Rank Structure from Latent Domains for Domain Generalization
Zheng Xu, Wen Li, Li Niu, and Dong Xu
European Conference on Computer Vision (ECCV), 2014

@inproceedings{xu_eccv2014,
  author    = {Zheng Xu and Wen Li and Li Niu and Dong Xu},
  title     = {Exploiting Low-Rank Structure from Latent Domains for Domain Generalization},
  booktitle = {ECCV},
  year      = {2014}
}
